# ECE 4510 Project 2

Project 2 consists of 3 different tasks taking place in MATLAB and Jupyter Notebook using OpenCV. 
